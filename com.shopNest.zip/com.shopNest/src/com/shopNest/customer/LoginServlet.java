package com.shopNest.customer;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopNest.dbHandler.DateFetcher;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/log")
public class LoginServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String name=req.getParameter("uname");
		String pas=req.getParameter("pas");
		if(name.length()==0||pas.length()==0){
			res.sendRedirect("login.jsp");
		}else if(name.equals("amaresh")){
			String ps=DateFetcher.getPassword(name);
			if(ps.equals(pas)){
				res.sendRedirect("adminhome.jsp");
			}else{
				res.sendRedirect("login.jsp");
			}
			
		}else{
			String ps1=DateFetcher.getCustomerPassword(name);
			if(ps1.equals(pas)){
				res.sendRedirect("home.jsp");
			}else{
				res.sendRedirect("login.jsp");
			}
		}
	
	}

}
