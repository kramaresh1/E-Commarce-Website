package com.shopNest.customer;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopNest.dbHandler.DataInjector;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/reg")
public class RegisterServlet extends HttpServlet {
	

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		String name=req.getParameter("name");
		String mail=req.getParameter("mail");
		String pass=req.getParameter("pass");
		String gender=req.getParameter("gender");
		String address=req.getParameter("address");
		if(name.length()==0||mail.length()==0||pass.length()==0||gender.length()==0||name.length()==0){
			res.sendRedirect("register.jsp");
		}else{
			try {
				int result=DataInjector.insert(name,mail,pass,gender,address);
				if(result==1){
					res.sendRedirect("login.jsp");
				}else{
					res.getWriter().println("problem accured");
				}
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
	}

	

}
