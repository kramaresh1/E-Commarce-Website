package com.shopNest.dbHandler;

import java.sql.*;

import oracle.jdbc.OracleDriver;





public class DataInjector {


	
	public static int insert(String name, String mail, String pass, String gender, String address) throws SQLException {
		 String user="system";
		 String password="system";
		 String url="jdbc:oracle:thin:@localhost:1521:xe";
		 Connection con=null;
		 PreparedStatement pp=null;
		 String query ="insert into customer values(?,?,?,?,?)";
		int res=5;
		
		try {
			DriverManager.registerDriver(new OracleDriver());
			con=DriverManager.getConnection(url, user, password);
		
		pp=con.prepareStatement(query);
		pp.setString(1, name);
		pp.setString(2, mail);
		pp.setString(3, pass);
		pp.setString(4, gender);
		pp.setString(5, address);
		pp.executeUpdate();
		res=1; 
		return res;
		} catch (Exception e) {
			e.printStackTrace();
		res=0; 
		return res;
			
		}finally {
			con.close();
			pp.close();
		}
		
		
	}

	public static int injectProduct(String pid, String pname, String pdesc, int price, String pimage) {
		 String user="system";
		 String password="system";
		 String url="jdbc:oracle:thin:@localhost:1521:xe";
		 Connection con=null;
		 PreparedStatement pp=null;
		 String query ="insert into products values(?,?,?,?,?)";
		 
		 try {
				DriverManager.registerDriver(new OracleDriver());
				con=DriverManager.getConnection(url, user, password);
			int id=Integer.valueOf(pid);
			pp=con.prepareStatement(query);
			pp.setInt(1, id);
			pp.setString(2, pname);
			pp.setString(3, pdesc);
			pp.setInt(4, price);
			pp.setString(5, pimage);
			pp.executeUpdate();
			return 1;
			 
			
			} catch (Exception e) {
				e.printStackTrace();
				return 0;
				
			}finally {
				try {
					con.close();
					pp.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		
	}
	
	

}
