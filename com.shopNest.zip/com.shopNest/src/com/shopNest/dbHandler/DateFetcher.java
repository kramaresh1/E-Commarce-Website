package com.shopNest.dbHandler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import com.shopNest.product.Product;

import oracle.jdbc.OracleDriver;

public class DateFetcher {

	public static String getPassword(String name) {
		String ps="";
		String user="system";
		String password="system";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection con=null;
		PreparedStatement pp=null;
		ResultSet rs=null;
		String query ="select password from shopnestAdmin where adminname=?";

		try {
			DriverManager.registerDriver(new OracleDriver());
			con=DriverManager.getConnection(url, user, password);

			pp=con.prepareStatement(query);
			pp.setString(1, name);


			rs=pp.executeQuery();

			if(rs.next()){
				ps+=rs.getString(1);

			}
			return ps;


		} catch (Exception e) {
			e.printStackTrace();
			return "error";

		}finally {
			try {
				con.close();
				pp.close();
				rs.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}





	}

	public static String getCustomerPassword(String name) {
		String user="system";
		String password="system";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection con=null;
		PreparedStatement pp=null;
		ResultSet rs=null;
		String query ="select pass from customer where uname=?";
		String ps="";
		try {
			DriverManager.registerDriver(new OracleDriver());
			con=DriverManager.getConnection(url, user, password);

			pp=con.prepareStatement(query);
			pp.setString(1, name);


			rs=pp.executeQuery();
			if(rs.next()){
				ps+=rs.getString(1);

			}
			return ps;


		} catch (Exception e) {
			e.printStackTrace();
			return "error";

		}finally {
			try {
				con.close();
				pp.close();
				rs.close();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public static List getCustomerData() throws SQLException {
		String user="system";
		String password="system";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		String query ="select uname,mail,gender,address from customer";
	  List ll=new LinkedList();
		try {
			DriverManager.registerDriver(new OracleDriver());
			con=DriverManager.getConnection(url, user, password);

			stmt=con.createStatement();
			rs=stmt.executeQuery(query);
			while(rs.next()){
				String temp=rs.getString(1)+":"+rs.getString(2)+":"+rs.getString(3)+":"+rs.getString(4);
			    ll.add(temp);
			    
			}
			return ll;
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			con.close();
			stmt.close();
			rs.close();

		}
		return ll;
	}
	
	
	public static List getProductData() throws SQLException {
		String user="system";
		String password="system";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		String query ="select * from products";
	  List lp=new LinkedList();
		try {
			DriverManager.registerDriver(new OracleDriver());
			con=DriverManager.getConnection(url, user, password);

			stmt=con.createStatement();
			rs=stmt.executeQuery(query);
			while(rs.next()){
				String temp=rs.getString("pid")+":"+rs.getString("pname")+":"+rs.getString("pdesc")+":"+rs.getString("pprice")+":"+rs.getString("pimg");
			    lp.add(temp);
			   
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			con.close();
			stmt.close();
			rs.close();

		}
		return lp;
	}

	public static Product getProductById(int pid) {
		
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String user="system";
		String password="system";
		String sql="SELECT pname,pprice FROM products WHERE pid=?";
		Product p=null;
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, pid);
			ResultSet rs=ps.executeQuery();
			rs.next();
			String pname=rs.getString(1);
			int pprice=rs.getInt(2);
			
			p=new Product(pid,pname,pprice);
		}catch(Exception e){
			System.out.println("Problem in fetching product by id");
			e.printStackTrace();
		}			
		finally {
			return p;
		}
	}
	}


