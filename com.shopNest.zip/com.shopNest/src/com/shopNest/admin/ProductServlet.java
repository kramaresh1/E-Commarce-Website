package com.shopNest.admin;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopNest.dbHandler.DataInjector;

@WebServlet("/addp")
public class ProductServlet extends HttpServlet {
	   
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String pid=req.getParameter("pid");
		String pname=req.getParameter("pname");
		String pdesc=req.getParameter("pdesc");
		int price=Integer.valueOf(req.getParameter("price"));
		String pimage=req.getParameter("pimage");
		
		if(pid.length()==0||pname.length()==0||pdesc.length()==0||price<0){
			res.sendRedirect("addproduct.jsp");
		}else{
			int a=DataInjector.injectProduct(pid,pname,pdesc,price,pimage);
			if(a==1){
				res.sendRedirect("adminhome.jsp");
			}else{
				res.getWriter().println("some problem accured");
			}
		}
	}

}
